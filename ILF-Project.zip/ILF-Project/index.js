/**
 * This script sets up an incoming payment on a receiving wallet address,
 * and a quote on the sending wallet address (after getting grants for both of the resources).
 *
 * The final step is asking for an outgoing payment grant for the sending wallet address.
 * Since this needs user interaction, you will need to navigate to the URL, and accept the interactive grant.
 *
 * To start, please add the variables for configuring the client & the wallet addresses for the payment.
 */
//Configuracion Inicial
import {createAuthenticatedClient} from "@interledger/open-payments";
import fs from "fs";
import { isFinalizedGrant } from "@interledger/open-payments";
import Readline from "readline/promises";

//Importar dependencias y configurar cliente
(async () => {
  const privateKey= fs.readFileSync("private.key", "utf8");
  const client = await createAuthenticatedClient({
    walletAddressUrl: "https://ilp.interledger-test.dev/ramirez", // Make sure the wallet address starts with https:// (not $), and has no trailing slashes
    privateKey: "private.key",
    keyId: "303ad4e7-9ba9-447d-a684-36587ed7c4c1",
  });

  const sendingWalletAddress = await client.walletAddress.get({
    url: "https://ilp.interledger-test.dev/platzialex", // Make sure the wallet address starts with https:// (not $)
  });
  const receivingWalletAddress = await client.walletAddress.get({
    url: "https://ilp.interledger-test.dev/becerril", // Make sure the wallet address starts with https:// (not $)
  });

  console.log(sendingWalletAddress, receivingWalletAddress);

  //obtener concesion pago entrante
  const incomingPaymentGrant = await client.grant.request(
    {
      url: receivingWalletAddress.authServer,
    },
    {
      access_token: {
        access: [
          { 
            type: "incoming-payment",
            actions: ["create"],
          }
        ]
      }
    }
  );


//Crear un pago entrante para el receptor
  const incomingPayment = await client.incomingPayment.create(
    {
      url: receivingWalletAddress.resourceServer,
      accessToken: incomingPaymentGrant.access_token.value,
    },
    {
      walletAddress: receivingWalletAddress.id,
      incomingAmount:{
        assetCode: receivingWalletAddress.assetCode,
        assetScale: receivingWalletAddress.assetScale,
        value:"1000",
      },
    }
  );
  console.log({incomingPayment});

  //Crear concesion para cotizacion
const quoteGrant = await client.grant.request(
  {
    url: sendingWalletAddress.authServer,
  },
  {
    access_token: {
      access: [
        {
          type: "quote",
          actions: ["create"],
        }
      ]
    }
   }
);

if(!isFinalizedGrant(quoteGrant)){
    throw new Error("Se espera finalice la concesion");
}

  console.log(quoteGrant);

  //Obtener una cotizacion para el remitente
const quote = await client.quote.create(
  {
    url: receivingWalletAddress.resourceServer,
    accessToken: quoteGrant.access_token.value,
  },
  {
    walletAddress: sendingWalletAddress.id,
    receiver: incomingPayment.id,
    method: "ilp",
  }
);

console.log({quote});

//Obtener consesion del pago saliente

const outgoingPaymentGrant = await client.grant.request(
    {
      url: sendingWalletAddress.authServer,
    },
    {
      access_token: {
        access: [
          {
            type: "outgoing-payment",
            actions: ["create"],
            limits: {
              debitAmount: quote.debitAmount,
            },
            identifier: sendingWalletAddress.id,
          },
        ],
      },
      interact: {
        start: ["redirect"],
      },
    }
);
console.log({outgoingPaymentGrant})

//Concesion saliente
 await Readline
 .createInterface({ 
      input: process.stdin, 
      output: process.stdout,
    })
    .question("\nPresione Enter para continuar con el pago...");


//Finalizar concesion de pago saliente
const finalizedOutgoingPaymentGrant = await client.grant.continue({
      url: outgoingPaymentGrant.continue.uri,
      accessToken: outgoingPaymentGrant.continue.access_token.value,
    });
    if (!isFinalizedGrant(finalizedOutgoingPaymentGrant)) {
      throw new Error("Se espera finalice la concesion");
    }

    //Continuar con la cotizacion de pago saliente
    const outgoingPayment = await client.outgoingPayment.create(
    {
      url: sendingWalletAddress.resourceServer,
      accessToken: finalizedOutgoingPaymentGrant.access_token.value,
    },
    {
      walletAddress: sendingWalletAddress.id,
      quoteId: quote.id,
    }
  );
  console.log({outgoingPayment});

})();